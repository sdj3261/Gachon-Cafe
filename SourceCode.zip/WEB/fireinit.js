// Initialize Firebase
// TODO: Replace with your project's customized code snippet
var firebaseConfig = {
   apiKey: "AIzaSyBrUDFmP7TuoAMWQYXfm_0V-MsI9y_MwAs",
   authDomain: "my-se-project-116ab.firebaseapp.com",
   databaseURL: "https://my-se-project-116ab.firebaseio.com",
   projectId: "my-se-project-116ab",
   storageBucket: "my-se-project-116ab.appspot.com",
   messagingSenderId: "1098112469005",
   appId: "1:1098112469005:web:37b634d8642370acdc2d44",
   measurementId: "G-SZ9M68FPEG"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
firebase.analytics();


var database = firebase.database();
